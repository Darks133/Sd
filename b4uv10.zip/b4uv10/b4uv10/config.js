require("./database/module")
global.imageurl = 'https://i.top4top.io/p_3208zxsht0.jpg'
global.owner = "923465148502"
global.namabot = "sed satan v3"
global.nomorbot = "923465148502"
global.namaCreator = "sed satan v3"
global.versisc = 'b4u v6.9'
global.packname = "sedsatan"
global.author = "b4u x sad"
global.jumlah = "5"
global.codeInvite = ""
global.danapay = "https://i.top4top.io/p_3208zxsht0.jpg" //ubah qris payment
global.isLink = 'https://whatsapp.com/channel/0029ValNvcn9hXF0GBPgzF1K'
global.autoJoin = false
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})