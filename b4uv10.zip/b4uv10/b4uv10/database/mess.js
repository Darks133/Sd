require("./global")

const mess = {
   wait: "/> loading...`",
   success: ">/ successfully loads",
   on: "/> fitur online", 
   off: "/> fitur offline",
   query: {
       text: "/> masukan teks bro",
       link: "/> mana linknya",
   },
   error: {
       fitur: "/> Oops fitur maintenance",
   },
   only: {
       group: "/> fitur khusus group",
       private: "/> fitur khusus private chat",
       owner: "/> fitur khusus owner bot",
       admin: "/> fitur khusus admin group",
       badmin: "/> maaf bot bukan admin",
       premium: "/> fitur khusus user premium",
   }
}

global.mess = mess

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})